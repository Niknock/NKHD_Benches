How to change the Ad on the Benches:

1. Edit prop_bench_add_02.dds
2. Open Codewalker RPF Explorer (https://github.com/dexyfex/CodeWalker)
3. Open Bench you want to Edit
4. Press on the Top Left on "Texture Editor"
5. Press onto "prop_bench_add_02"
6. Press Replace and select the Image you want
7. Save file